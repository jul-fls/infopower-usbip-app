#!/bin/sh
softname=ViewPower
id=`ps auNx | grep "$softname" | grep tomcat | awk '{print $2}'`
if [[ $id ]];
   then
     kill -9 $id
fi
