#!/bin/sh
softpath=/home/julien/InfoPower/StartMain
servername='StartMain'
localname='/etc/rc.local'
localname2='/etc/rc.d/rc.local'
localname3='/etc/rc.d/after.local'

exit0="exit 0"
params="i\\$softpath &"
delparams="\\/$servername/d"

sudo sed -i '-e /StartMain/d' $localname3
`cat $localname3 | grep -q "$exit0"`
if [ $? -eq 0 ]
  then
#   echo "include $exit0"
sudo chmod +x /etc/rc.d/after.local
     i=`sudo  sed -n '$=' $localname3`
#     i=$(($i-1))softpath
     sudo sed -i "$i $params" $localname3
else
#   echo "not include $exit0"
   sudo sed -i "$ $params" $localname3
fi

sudo sed -i '-e /StartMain/d' $localname2

`cat $localname2 | grep -q "$exit0"`
if [ $? -eq 0 ]
  then
#   echo "include $exit0"
sudo chmod +x /etc/rc.d/rc.local
     i=`sudo sed -n '$=' $localname2`
#     i=$(($i-1))softpath
     sudo sed -i "$i $params" $localname2
else
#   echo "not include $exit0"
   sudo sed -i "$ $params" $localname2
fi

sudo sed -i '-e /StartMain/d' $localname

`cat $localname | grep -q "$exit0"`
if [ $? -eq 0 ]
  then
#   echo "include $exit0"
sudo chmod +x /etc/rc.local
     i=`sudo sed -n '$=' $localname`
#     i=$(($i-1))softpath
echo $i
     sudo sed -i "$i $params" $localname
else
#   echo "not include $exit0"
   sudo sed -i "$ $params" $localname
fi

if [ ! -f /lib/libc.so.6 ]; then
  lib_location=$(locate libc.so.6)
  sudo ln -s  $lib_location /lib/libc.so.6
fi
