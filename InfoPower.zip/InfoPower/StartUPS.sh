#!/bin/sh
pids=$(netstat -ln | grep 51099 | awk '{print $6}')
pids=${pids%/*}
if [ -z "$pids" ]; then
	/home/julien/InfoPower/StartMain &
fi


